package controllers;

public class AppMenuController {
}
