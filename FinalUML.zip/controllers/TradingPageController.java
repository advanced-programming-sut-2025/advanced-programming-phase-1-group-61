package controllers;

public class TradingPageController {
}
