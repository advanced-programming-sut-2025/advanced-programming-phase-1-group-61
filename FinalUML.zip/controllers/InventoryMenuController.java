package controllers;

public class InventoryMenuController {
}
