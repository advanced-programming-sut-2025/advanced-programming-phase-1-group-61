package controllers;

public class ShopMenuController {
}
