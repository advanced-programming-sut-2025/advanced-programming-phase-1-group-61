package views;

import java.util.Scanner;

public class ShopMenu implements AppMenu{
    @Override
    public void check(Scanner scanner) {

    }
}
