package models.resource;

import models.enums.TreeType;

public class Tree extends Resource{
    private int age;
    TreeType type;

}
