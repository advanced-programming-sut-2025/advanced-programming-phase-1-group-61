package models;

import java.util.ArrayList;

public class User {
    private String username;
    private String email;
    private String password;
    private ArrayList<Game> allGames=new ArrayList<>();
}
