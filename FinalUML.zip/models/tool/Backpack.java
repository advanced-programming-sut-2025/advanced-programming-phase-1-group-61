package models.tool;

import models.Item;

import java.util.ArrayList;

public class Backpack extends Tool{
    private ArrayList<Item> items=new ArrayList<>();
    public void showItems(){
        //todo
    }
    public void addItem(Item item){
        //todo
    }
}
