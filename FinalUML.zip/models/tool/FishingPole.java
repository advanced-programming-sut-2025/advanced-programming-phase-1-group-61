package models.tool;

public class FishingPole extends Tool{
}
