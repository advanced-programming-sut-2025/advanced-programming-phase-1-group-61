package models.tool;

public class Axe extends Tool{
}
