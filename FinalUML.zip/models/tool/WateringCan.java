package models.tool;

public class WateringCan extends Tool{
}
