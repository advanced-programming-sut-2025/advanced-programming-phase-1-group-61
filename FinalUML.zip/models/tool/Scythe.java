package models.tool;

public class Scythe extends Tool{
}
