package models.tool;

public class Shear extends Tool{
}
