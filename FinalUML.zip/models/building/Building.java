package models.building;

public class Building {
}
