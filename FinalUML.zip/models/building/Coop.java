package models.building;

public class Coop extends Building {
}
