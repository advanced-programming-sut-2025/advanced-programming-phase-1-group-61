package models.map;

import models.workBench.WorkBench;

import java.util.ArrayList;

public class Map {
    Tile[][] tiles;
    Weather weather;
    ArrayList<WorkBench> workBenches=new ArrayList<>();
}
