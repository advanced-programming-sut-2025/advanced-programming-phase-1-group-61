package models.enums;

public enum WeatherState {
    Sunny,
    Rain,
    Storm,
    Snow;
}
