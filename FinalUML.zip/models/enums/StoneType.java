package models.enums;

public enum StoneType {
    Gold,Normal;
}
