package models.enums;

import java.util.List;

public enum RequestConstants {
}
