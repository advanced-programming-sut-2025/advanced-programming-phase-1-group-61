package models.enums;

public enum TileType {
    soil,
    water,
    grass;
}
