package models.enums;

public enum ToolType {
    Axe,Backpack,FishingPole,Hoe,MilkPail,PickAxe,Scythe,Shear,WateringCan;
    public String toString(){
        return this.name();
    }
}
