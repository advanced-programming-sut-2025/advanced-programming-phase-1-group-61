package models.enums;

import views.*;

import java.util.Scanner;

public enum Menu {
    MAIN_MENU((AppMenu) new MainMenu()),
    LOGIN_MENU((AppMenu) new LoginMenu()),
    PRODUCT_MENU((AppMenu) new GameMenu()),
    STORE_MENU((AppMenu) new ShopMenu()),
    USER_MENU((AppMenu) new InventoryMenu()),
    EXIT_MENU((AppMenu) new ExitMenu());

    private final AppMenu menu;

    Menu(AppMenu menu) {
        this.menu = menu;
    }

    public AppMenu getMenu() {
        return menu;
    }

    public void checkCommand(Scanner scanner) {
        this.menu.check(scanner);
    }
}
