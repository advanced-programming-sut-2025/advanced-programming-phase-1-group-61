package models.enums;

public enum ShopType {
    BlackSmith,
    SuperMarket;
}
