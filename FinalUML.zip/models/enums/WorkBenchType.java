package models.enums;

public enum WorkBenchType {
    WOODWORKING,
    BLACKSMITHING,
    ALCHEMY,
    COOKING;
}
