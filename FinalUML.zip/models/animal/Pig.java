package models.animal;

public class Pig extends Animal {
}
