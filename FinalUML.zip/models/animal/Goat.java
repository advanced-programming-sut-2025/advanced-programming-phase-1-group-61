package models.animal;

public class Goat extends Animal {
}
