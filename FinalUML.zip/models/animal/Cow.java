package models.animal;

public class Cow extends Animal {
}
