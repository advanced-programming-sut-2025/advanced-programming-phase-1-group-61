package models.animal;

public class Rabbit extends Animal {
}
