package models.animal;

public class Sheep extends Animal {
}
