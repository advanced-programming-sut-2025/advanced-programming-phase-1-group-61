package models.animal;

public class Dianasour extends Animal{
}
