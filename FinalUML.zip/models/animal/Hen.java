package models.animal;

public class Hen extends Animal {
}
