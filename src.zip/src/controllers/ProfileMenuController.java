package controllers;

public class ProfileMenuController {
}
