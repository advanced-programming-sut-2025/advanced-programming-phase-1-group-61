package models.workBench;

import models.enums.WorkBenchType;

public class WorkBench {
    private WorkBenchType type;
}
