package models.building;

public class Barn extends Building {
}
