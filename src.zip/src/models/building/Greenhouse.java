package models.building;

public class Greenhouse extends Building{

}
