package models.date;

import models.enums.DaysOfTheWeek;
import models.enums.Season;

public class Date {
    private DaysOfTheWeek day;
    private Season season;
    public Date(){
        day=DaysOfTheWeek.Sunday;
        season=Season.Spring;
        //day time is based on minute
        day.setTime(540);
    }
    public void changeDay(DaysOfTheWeek day){
        this.day = day;
    }

    public void changeSeason(Season newSeason){
        this.season=newSeason;
    }

    public Season getSeason(){
        return season;
    }

    public DaysOfTheWeek getDay() {
        return day;
    }

}
