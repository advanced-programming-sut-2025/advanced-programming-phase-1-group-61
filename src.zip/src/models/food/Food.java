package models.food;

public class Food {
    private String name;
    private int heal , foodAmount ;
    private double price;

}
