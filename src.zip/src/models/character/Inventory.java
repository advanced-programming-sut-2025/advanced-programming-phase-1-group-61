package models.character;

import models.tool.Tool;

import java.util.ArrayList;

public class Inventory {
    private ArrayList<Tool> tools=new ArrayList<>();
}
