package models.tool;

public class Hoe extends Tool{
}
