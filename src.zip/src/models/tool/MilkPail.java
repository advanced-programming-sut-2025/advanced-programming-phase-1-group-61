package models.tool;

public class MilkPail extends Tool{
}
