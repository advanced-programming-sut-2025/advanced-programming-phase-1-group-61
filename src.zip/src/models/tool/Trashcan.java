package models.tool;

public class Trashcan extends Tool {
    public void getRidOfItem(Tool tool){
        //todo
    }
}
