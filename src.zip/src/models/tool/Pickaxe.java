package models.tool;

public class Pickaxe extends Tool{
}
