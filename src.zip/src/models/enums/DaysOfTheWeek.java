package models.enums;

public enum DaysOfTheWeek {
    Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday;
    private int time;
    public void increaseTime(int increase){
        time+=increase;
        if(time>24*60){
            changeDay();
            time-=24*60;
        }
    }
    public void setTime(int time){
        this.time=time;
    }
    public int getTime(){
        return time;
    }
    public void changeDay(){
        //todo
    }
}
