package models.enums;

public enum Season {
    Spring,Summer,Fall,Winter;
}
