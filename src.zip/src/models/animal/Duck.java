package models.animal;

public class Duck extends Animal {
}
