package models;

import models.date.Date;
import models.map.Map;

import java.util.ArrayList;

public class Game {
    private static int idCounter=1;
    private int id;
    private Map map;
    private ArrayList<Character> allCharacters=new ArrayList<>();
    Date date=new Date();
    public Game(){
        id=idCounter++;
    }
    public void runGame(){
        //TODO
    }
}
