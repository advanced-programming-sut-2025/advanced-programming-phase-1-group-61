package models.resource;

public class Resource {
    protected int health;
}
