package models.resource;

public class Soil{

}
